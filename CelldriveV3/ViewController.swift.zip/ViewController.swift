// Celldrive code 7 march 2018
//  ViewController.swift
//  Celldrive
//
//  Created by ramya  on 16/02/18./Users/venkatakrishnan/Desktop/CellDriveIOS/CellDriveIOS/ViewController.swift
//  Copyright © 2018 ramya . All rights reserved.
//

import UIKit
import CoreLocation
import CoreTelephony
import CallKit
import UserNotifications

class ViewController: UIViewController {
    let sharedPref = UserDefaults.standard
    var currentLocation: CLLocation!
    var locManager = CLLocationManager()
    var callObs : CXCallObserver!
    var callObserver: CXCallObserver!
    var bgTask = UIBackgroundTaskIdentifier()
    var backgroundTask: UIBackgroundTaskIdentifier = UIBackgroundTaskInvalid
    var registered : Bool = false
    @IBOutlet var stackOTP: UIStackView!
    @IBOutlet var stackSuccess: UIStackView!
    @IBOutlet var phone_txt: UITextField!
    @IBOutlet var email_txt: UITextField!
    
    @IBOutlet var stackRegister: UIStackView!
    @IBOutlet var name_txt: UITextField!
    
    @IBOutlet var txt_log: UILabel!
    @IBOutlet weak var otp_txt: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.sharedPref.setValue(false, forKey: "clstate")//flag for call state setting false as default
        
        // Get User Authorization to use send/receive Notification
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.badge,.sound], completionHandler: {didallow, error in })
        // Get User Authorization to use Location Services
        self.locManager.requestAlwaysAuthorization()
        
        registerBackgroundTask()//to start background task
        startTask()//to start the task which should be loaded when user enters app
        
    }
    func startTask(){
        if self.sharedPref.string(forKey: "token") != nil{//checks if the user is registered or not
            
            //checks for authorization for location service
            let authorizationStatus = CLLocationManager.authorizationStatus()
            if authorizationStatus != .authorizedAlways {
                // User has not authorized access to location information.
                return
            }
            //checks the location service is enabled or not
            if CLLocationManager.locationServicesEnabled() {
                //starts the background task for location tracking
                locManager.delegate = self as CLLocationManagerDelegate
                locManager.desiredAccuracy = kCLLocationAccuracyBest
                locManager.requestAlwaysAuthorization()
                locManager.distanceFilter = 100 //set filter for significant location
                locManager.allowsBackgroundLocationUpdates = true
                locManager.pausesLocationUpdatesAutomatically = false
                locManager.requestWhenInUseAuthorization()
                locManager.startUpdatingLocation()
                locManager.startMonitoringSignificantLocationChanges()
            }
            if !CLLocationManager.significantLocationChangeMonitoringAvailable() {
                // The service is not available.
                return
            }
            //runs if already registered user
            self.stackRegister.isHidden = true
            self.stackOTP.isHidden = true
            self.stackSuccess.isHidden = false
        }
        else{
            //for new user
            self.stackRegister.isHidden = false
            self.stackOTP.isHidden = true
            self.stackSuccess.isHidden = true
        }
    }
    func registerBackgroundTask() {
        //registering background task
        backgroundTask = UIApplication.shared.beginBackgroundTask { [weak self] in
            self?.endBackgroundTask()
        }
        assert(backgroundTask != UIBackgroundTaskInvalid)
        
        print("bg task started")
        if self.sharedPref.string(forKey: "token") != nil{//checks for token exits in shared preference
            let authorizationStatus = CLLocationManager.authorizationStatus()
            if authorizationStatus != .authorizedAlways {
                // User has not authorized access to location information.
                return
            }
            if CLLocationManager.locationServicesEnabled() {
                locManager.delegate = self as CLLocationManagerDelegate
                locManager.desiredAccuracy = kCLLocationAccuracyBest
                locManager.requestAlwaysAuthorization()
                locManager.distanceFilter = 100 //set filter for significant location
                locManager.allowsBackgroundLocationUpdates = true
                locManager.pausesLocationUpdatesAutomatically = false
                locManager.requestWhenInUseAuthorization()
                locManager.startUpdatingLocation()
                locManager.startMonitoringSignificantLocationChanges()
            }
            if !CLLocationManager.significantLocationChangeMonitoringAvailable() {
                // The service is not available.
                return
            }
            
        }
    }
    
    func endBackgroundTask() {
        //end background task
        print("Background task ended.")
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = UIBackgroundTaskInvalid
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //button click event for user registration
    @IBAction func RegisterBtn(_ sender: Any) {
        
        let name = name_txt.text
        let email = email_txt.text
        let phone = phone_txt.text
        let parameters = ["name": name,"email": email,"phone":phone,"fcm_token":"abcdefghijklmnopqrstuvwxyz"]
        
        guard let url = URL (string: "http://ec2-54-191-172-248.us-west-2.compute.amazonaws.com/sandbox/v1/user/") else{ return}
        print("Parameters:\(parameters)")
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: [])else{ return}
        request.httpBody = httpBody
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response{
                print("Response:\(response)")
                
            }
            if let data = data{
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String : Any]
                    if let token = json!["token"]{
                        self.sharedPref.setValue(token, forKey: "token")
                        print("TOKEN VALUE 1 : \(String(describing: self.sharedPref.string(forKey: "token")))")
                    }
                    
                }catch{
                    print(error)
                }
            }
            }.resume()
        
        self.stackOTP.isHidden = false
        self.stackRegister.isHidden = true
        self.stackSuccess.isHidden = true
    }
    //button click event for user verification
    @IBAction func VerifyBtn(_ sender: Any) {
        
        if let token = self.sharedPref.string(forKey: "token"){
            self.stackOTP.isHidden = true
            self.stackRegister.isHidden = true
            self.stackSuccess.isHidden = false
            print("TOKEN VALUE 2 : \(token)")
            let otp = otp_txt.text
            let parameters = ["otp": otp]
            let auth = "JWT \(token)"
            guard let url = URL (string: "http://ec2-54-191-172-248.us-west-2.compute.amazonaws.com/sandbox/v1/user/verify/") else{ return}
            var request = URLRequest(url: url)
            request.httpMethod = "POST"
            guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: [])else{ return}
            request.httpBody = httpBody
            request.addValue(auth, forHTTPHeaderField: "Authorization")
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let session = URLSession.shared
            session.dataTask(with: request) { (data, response, error) in
                if let response = response{
                    print("Response:\(response)")
                    self.registerBackgroundTask()
                    self.startTask()
                }
                if let error = error{
                    print("Error:\(error)")
                }
                if let data = data{
                    print("Data:\(data)")
                }
                
                }.resume()
            
        }
        
    }
    
}
//delegate function for notification handling
extension ViewController: UNUserNotificationCenterDelegate {
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: (UNNotificationPresentationOptions) -> Void) {
        // some other way of handling notification
        completionHandler([.alert, .sound])
    }
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: () -> Void) {
        
        completionHandler()
        
    }
    
}
//delegate function for location changes
extension ViewController : CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager,  didUpdateLocations locations: [CLLocation]) {
        let location: CLLocation = locations.last!
        // Do something with the location.
        
        //runs when the user location changes
        txt_log.text = " Speed:" + String(location.speed)
        
        //starting call observer to check user is in call or not
        self.callObs = CXCallObserver()
        self.callObs.setDelegate(self as CXCallObserverDelegate, queue: nil)
        print("Monitoring Calls")
        
        print("call state flag:\(self.sharedPref.bool(forKey: "clstate"))")
        
        //checks if user speed exceeds 2 miles/sec
        if(Double((locManager.location?.speed)!) >= 2){
            //check for call state flag
        if self.sharedPref.bool(forKey: "clstate") == true {
            //checks for token is valid
            if let token = self.sharedPref.string(forKey: "token"){
                //first time parent value is 0, after 1st incident save in server its value increases by the value returned as response string
                let  parent = self.sharedPref.integer(forKey: "parent")
                print("inc_parent 1: \(parent)")
                
                //getting user location parameters
                let inc_lng = locManager.location?.coordinate.longitude
                let inc_lat = locManager.location?.coordinate.latitude
                let inc_speed = locManager.location?.speed
                
                //for local notification , used for testing
                let content = UNMutableNotificationContent()
                content.title = "Location Updated"
                content.subtitle = "user in call"
                content.body = "user in call while location changed"
                content.badge = 1
                let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
                let requesto = UNNotificationRequest(identifier: "timerDone", content: content, trigger: trigger)
                UNUserNotificationCenter.current().add(requesto, withCompletionHandler: nil)
                
                //starting async task for incident reporting to server
                DispatchQueue.main.async(execute:{
                    let auth = "JWT \(token)"
                    let parameters = ["inc_lat": Float(inc_lat!),"inc_lng": Float(inc_lng!),"inc_speed":Float(inc_speed!),"inc_summary":"from ios - testing","inc_parent":parent] as [String : Any]
                    print("inc_parent 2: \(parent)")
                    print("parameter:\(parameters)")
                    guard let url = URL (string: "http://ec2-54-191-172-248.us-west-2.compute.amazonaws.com/sandbox/v1/user/incident") else{ return}
                    var request = URLRequest(url: url)
                    request.httpMethod = "POST"
                    guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: [])else{ return}
                    request.httpBody = httpBody
                    request.addValue(auth, forHTTPHeaderField: "Authorization")
                    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
                    let session = URLSession.shared
                    session.dataTask(with: request) { (data, response, error) in
                        if let response = response{
                            print("Response:\(response)")
                            self.sharedPref.setValue(1, forKey: "parent")
                            print("inc_parent 3: \(parent)")
                        }
                        }.resume()
                })
                
            }
        } else{}
        
         }
        
    }
    
}
//call observer delegate fired when started monitoring calls
extension ViewController : CXCallObserverDelegate
{
    func callObserver(_: CXCallObserver, callChanged: CXCall)
    {
        //Check if callObserver has fired...
        print("callObserver has fired...")
        
        //fired when user call state ended
        if(callChanged.hasEnded)
        {
            print("Call Ended")
            self.sharedPref.setValue(0, forKey: "parent")
            let  parent = self.sharedPref.integer(forKey: "parent")
            print("inc_parent 4: \(parent)")
            self.sharedPref.setValue(false, forKey: "clstate")
            
        }
            //fired when user call state dialing

        else if callChanged.isOutgoing == true && callChanged.hasConnected == false {
            print("Dialing")
        }
            //fired when user call state incoming

        else if callChanged.isOutgoing == false && callChanged.hasConnected == false && callChanged.hasEnded == false {
            print("Incoming")
        }
            //fired when user call state connected

        else if callChanged.hasConnected == true && callChanged.hasEnded == false {
            print("Connected")
            
            //set flag for call state
            self.sharedPref.setValue(true, forKey: "clstate")
            
        }
        
    }
}




